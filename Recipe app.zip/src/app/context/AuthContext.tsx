import { createContext, useContext, useState, useEffect, ReactNode } from "react";

export interface User {
  username: string;
  level: number;
  xp: number;
  totalXp: number;
  completedRecipes: string[];
  achievements: string[];
  streak: number;
  lastLoginDate: string;
}

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => boolean;
  signup: (username: string, password: string) => boolean;
  logout: () => void;
  addRecipeXp: (recipeId: string, xp: number) => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const XP_PER_LEVEL = 500;

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    // Check if user is logged in
    const savedUser = localStorage.getItem("currentUser");
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      // Check streak
      const today = new Date().toDateString();
      const lastLogin = new Date(userData.lastLoginDate).toDateString();
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      
      if (lastLogin === yesterday) {
        userData.streak += 1;
      } else if (lastLogin !== today) {
        userData.streak = 1;
      }
      
      userData.lastLoginDate = today;
      setUser(userData);
      localStorage.setItem("currentUser", JSON.stringify(userData));
    }
  }, []);

  const signup = (username: string, password: string): boolean => {
    if (!username || !password || password.length < 4) {
      return false;
    }

    const users = JSON.parse(localStorage.getItem("users") || "{}");
    
    if (users[username]) {
      return false; // User already exists
    }

    users[username] = password;
    localStorage.setItem("users", JSON.stringify(users));

    const newUser: User = {
      username,
      level: 1,
      xp: 0,
      totalXp: 0,
      completedRecipes: [],
      achievements: ["Beginner Chef"],
      streak: 1,
      lastLoginDate: new Date().toDateString()
    };

    setUser(newUser);
    localStorage.setItem("currentUser", JSON.stringify(newUser));
    return true;
  };

  const login = (username: string, password: string): boolean => {
    const users = JSON.parse(localStorage.getItem("users") || "{}");
    
    if (users[username] !== password) {
      return false;
    }

    const savedUserData = localStorage.getItem(`user_${username}`);
    let userData: User;

    if (savedUserData) {
      userData = JSON.parse(savedUserData);
      
      // Update streak
      const today = new Date().toDateString();
      const lastLogin = new Date(userData.lastLoginDate).toDateString();
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      
      if (lastLogin === yesterday) {
        userData.streak += 1;
      } else if (lastLogin !== today) {
        userData.streak = 1;
      }
      
      userData.lastLoginDate = today;
    } else {
      userData = {
        username,
        level: 1,
        xp: 0,
        totalXp: 0,
        completedRecipes: [],
        achievements: ["Beginner Chef"],
        streak: 1,
        lastLoginDate: new Date().toDateString()
      };
    }

    setUser(userData);
    localStorage.setItem("currentUser", JSON.stringify(userData));
    localStorage.setItem(`user_${username}`, JSON.stringify(userData));
    return true;
  };

  const logout = () => {
    if (user) {
      localStorage.setItem(`user_${user.username}`, JSON.stringify(user));
    }
    localStorage.removeItem("currentUser");
    setUser(null);
  };

  const addRecipeXp = (recipeId: string, xp: number) => {
    if (!user) return;

    const isNewRecipe = !user.completedRecipes.includes(recipeId);
    
    if (!isNewRecipe) return; // Already completed

    const newTotalXp = user.totalXp + xp;
    const newLevel = Math.floor(newTotalXp / XP_PER_LEVEL) + 1;
    const newXp = newTotalXp % XP_PER_LEVEL;

    const updatedUser: User = {
      ...user,
      xp: newXp,
      totalXp: newTotalXp,
      level: newLevel,
      completedRecipes: [...user.completedRecipes, recipeId]
    };

    // Check for new achievements
    const newAchievements = [...user.achievements];
    
    if (updatedUser.completedRecipes.length === 5 && !newAchievements.includes("First 5 Recipes")) {
      newAchievements.push("First 5 Recipes");
    }
    if (updatedUser.completedRecipes.length === 10 && !newAchievements.includes("Recipe Master")) {
      newAchievements.push("Recipe Master");
    }
    if (updatedUser.level === 5 && !newAchievements.includes("Level 5 Chef")) {
      newAchievements.push("Level 5 Chef");
    }
    if (updatedUser.streak >= 7 && !newAchievements.includes("Week Warrior")) {
      newAchievements.push("Week Warrior");
    }

    updatedUser.achievements = newAchievements;

    setUser(updatedUser);
    localStorage.setItem("currentUser", JSON.stringify(updatedUser));
    localStorage.setItem(`user_${user.username}`, JSON.stringify(updatedUser));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        login,
        signup,
        logout,
        addRecipeXp,
        isAuthenticated: !!user
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
