import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { RecipeCard } from "../components/RecipeCard";
import { recipes, categories } from "../data/recipes";
import { ChefHat, Search, BookOpen } from "lucide-react";

export function Home() {
  const featuredRecipes = recipes.slice(0, 6);
  const categoryList = categories.filter(cat => cat !== "All").slice(0, 6);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-950/20 dark:to-amber-950/20 py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex justify-center mb-6">
            <ChefHat className="size-16 text-orange-600" />
          </div>
          <h1 className="text-5xl font-bold mb-4">
            Discover Delicious Recipes
          </h1>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Explore thousands of recipes from around the world. Find your next
            favorite dish and start cooking today!
          </p>
          <div className="flex gap-4 justify-center">
            <Link to="/recipes">
              <Button size="lg" className="gap-2">
                <Search className="size-5" />
                Browse Recipes
              </Button>
            </Link>
            <Link to="/recipes">
              <Button size="lg" variant="outline" className="gap-2">
                <BookOpen className="size-5" />
                View All
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Browse by Category
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {categoryList.map((category) => (
              <Link
                key={category}
                to={`/recipes?category=${category}`}
                className="group"
              >
                <div className="p-6 rounded-lg border bg-card hover:bg-accent transition-colors text-center">
                  <p className="font-medium group-hover:text-primary">
                    {category}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Recipes Section */}
      <section className="py-16 px-4 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">Featured Recipes</h2>
            <Link to="/recipes">
              <Button variant="ghost">View All →</Button>
            </Link>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredRecipes.map((recipe) => (
              <RecipeCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted py-8 px-4 mt-16">
        <div className="max-w-7xl mx-auto text-center text-muted-foreground">
          <p>© 2026 Recipe App. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
