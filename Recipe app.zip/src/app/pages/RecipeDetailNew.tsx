import { useParams, useNavigate, Link } from "react-router";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { recipes } from "../data/recipes-new";
import { useAuth } from "../context/AuthContext";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Separator } from "../components/ui/separator";
import { Progress } from "../components/ui/progress";
import { Checkbox } from "../components/ui/checkbox";
import {
  ArrowLeft,
  Clock,
  Users,
  ChefHat,
  Trophy,
  Sparkles,
  Flame,
  Star,
  Share2,
  Heart,
  CheckCircle2
} from "lucide-react";
import { toast } from "sonner";
import confetti from "canvas-confetti";

export function RecipeDetailNew() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, addRecipeXp } = useAuth();
  const recipe = recipes.find((r) => r.id === id);
  const [checkedIngredients, setCheckedIngredients] = useState<number[]>([]);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);

  if (!recipe) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Recipe Not Found</h1>
          <Link to="/dashboard">
            <Button>Back to Dashboard</Button>
          </Link>
        </div>
      </div>
    );
  }

  const isCompleted = user?.completedRecipes.includes(recipe.id);
  const ingredientProgress = (checkedIngredients.length / recipe.ingredients.length) * 100;
  const stepsProgress = (completedSteps.length / recipe.instructions.length) * 100;

  const handleCompleteRecipe = () => {
    if (isCompleted) {
      toast.info("You've already completed this recipe!");
      return;
    }

    // Confetti animation
    confetti({
      particleCount: 100,
      spread: 70,
      origin: { y: 0.6 }
    });

    addRecipeXp(recipe.id, recipe.xpReward);
    
    toast.success(
      <div className="flex items-center gap-2">
        <Trophy className="size-5 text-yellow-500" />
        <div>
          <p className="font-bold">Recipe Completed!</p>
          <p className="text-sm">+{recipe.xpReward} XP earned 🎉</p>
        </div>
      </div>
    );

    setTimeout(() => navigate("/dashboard"), 2000);
  };

  const toggleIngredient = (index: number) => {
    setCheckedIngredients(prev =>
      prev.includes(index)
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const toggleStep = (index: number) => {
    setCompletedSteps(prev =>
      prev.includes(index)
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const difficultyColors = {
    "Beginner": "bg-green-500",
    "Intermediate": "bg-yellow-500",
    "Advanced": "bg-orange-500",
    "5-Star Chef": "bg-red-500"
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-orange-50 dark:from-slate-950 dark:to-orange-950/20">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" onClick={() => navigate(-1)} className="gap-2">
              <ArrowLeft className="size-4" />
              Back
            </Button>
            
            <Link to="/dashboard" className="flex items-center gap-2">
              <ChefHat className="size-6 text-orange-600" />
              <span className="font-bold hidden sm:inline">Recipe Quest</span>
            </Link>

            <div className="flex gap-2">
              <Button variant="ghost" size="icon">
                <Heart className="size-5" />
              </Button>
              <Button variant="ghost" size="icon">
                <Share2 className="size-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Recipe Header */}
          <div className="mb-8">
            <div className="flex flex-wrap gap-2 mb-4">
              <Badge className="gap-1 text-sm px-3 py-1">
                {recipe.courseType}
              </Badge>
              <Badge variant="secondary" className="gap-1 text-sm px-3 py-1">
                🌍 {recipe.cuisine}
              </Badge>
              {recipe.dietType.slice(0, 2).map((diet) => (
                <Badge key={diet} variant="outline" className="text-sm px-3 py-1">
                  {diet}
                </Badge>
              ))}
            </div>

            <h1 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
              {recipe.title}
            </h1>
            
            <p className="text-xl text-muted-foreground mb-6">{recipe.description}</p>

            {/* XP Reward Card */}
            <motion.div
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2 }}
              className="inline-block"
            >
              <Card className="bg-gradient-to-r from-purple-500 to-purple-700 text-white border-none">
                <CardContent className="p-4 flex items-center gap-3">
                  <Sparkles className="size-8" />
                  <div>
                    <p className="text-sm opacity-90">Complete to earn</p>
                    <p className="text-2xl font-bold">+{recipe.xpReward} XP</p>
                  </div>
                  {isCompleted && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      className="ml-auto"
                    >
                      <CheckCircle2 className="size-8 text-green-300" />
                    </motion.div>
                  )}
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Recipe Image */}
          <motion.div
            className="aspect-video rounded-xl overflow-hidden mb-8 shadow-2xl"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
          >
            <img
              src={recipe.image}
              alt={recipe.title}
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Recipe Info Cards */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <Card className="bg-gradient-to-br from-orange-100 to-orange-200 dark:from-orange-950/50 dark:to-orange-900/50 border-none">
              <CardContent className="p-6 text-center">
                <Clock className="size-8 mx-auto mb-2 text-orange-600" />
                <p className="text-sm text-muted-foreground">Time</p>
                <p className="text-2xl font-bold">{recipe.time} min</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-100 to-blue-200 dark:from-blue-950/50 dark:to-blue-900/50 border-none">
              <CardContent className="p-6 text-center">
                <Users className="size-8 mx-auto mb-2 text-blue-600" />
                <p className="text-sm text-muted-foreground">Servings</p>
                <p className="text-2xl font-bold">{recipe.servings}</p>
              </CardContent>
            </Card>

            <Card className={`bg-gradient-to-br ${difficultyColors[recipe.difficulty]} text-white border-none`}>
              <CardContent className="p-6 text-center">
                <Star className="size-8 mx-auto mb-2" />
                <p className="text-sm opacity-90">Difficulty</p>
                <p className="text-lg font-bold">{recipe.difficulty}</p>
              </CardContent>
            </Card>

            {recipe.calories && (
              <Card className="bg-gradient-to-br from-green-100 to-green-200 dark:from-green-950/50 dark:to-green-900/50 border-none">
                <CardContent className="p-6 text-center">
                  <Flame className="size-8 mx-auto mb-2 text-green-600" />
                  <p className="text-sm text-muted-foreground">Calories</p>
                  <p className="text-2xl font-bold">{recipe.calories}</p>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            {/* Ingredients */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Ingredients</span>
                  <Badge variant="secondary">
                    {checkedIngredients.length}/{recipe.ingredients.length}
                  </Badge>
                </CardTitle>
                <Progress value={ingredientProgress} className="h-2 mt-2" />
              </CardHeader>
              <CardContent className="space-y-3">
                <AnimatePresence>
                  {recipe.ingredients.map((ingredient, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex items-start gap-3 p-3 rounded-lg hover:bg-accent transition-colors"
                    >
                      <Checkbox
                        checked={checkedIngredients.includes(index)}
                        onCheckedChange={() => toggleIngredient(index)}
                        className="mt-1"
                      />
                      <span className={checkedIngredients.includes(index) ? "line-through text-muted-foreground" : ""}>
                        {ingredient}
                      </span>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </CardContent>
            </Card>

            {/* Instructions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Instructions</span>
                  <Badge variant="secondary">
                    {completedSteps.length}/{recipe.instructions.length}
                  </Badge>
                </CardTitle>
                <Progress value={stepsProgress} className="h-2 mt-2" />
              </CardHeader>
              <CardContent className="space-y-4">
                <AnimatePresence>
                  {recipe.instructions.map((instruction, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="flex gap-4 p-3 rounded-lg hover:bg-accent transition-colors"
                    >
                      <div className="flex-shrink-0">
                        <Checkbox
                          checked={completedSteps.includes(index)}
                          onCheckedChange={() => toggleStep(index)}
                          className="mt-1"
                        />
                      </div>
                      <div className="flex gap-3 flex-1">
                        <span className="font-bold text-orange-600 flex-shrink-0">
                          {index + 1}.
                        </span>
                        <span className={completedSteps.includes(index) ? "line-through text-muted-foreground" : ""}>
                          {instruction}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </CardContent>
            </Card>
          </div>

          {/* Occasion Tags */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle>Perfect For</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {recipe.occasion.map((occ) => (
                  <Badge key={occ} variant="outline" className="text-sm px-3 py-1">
                    {occ}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Complete Button */}
          <Separator className="my-8" />
          
          <div className="text-center">
            {!isCompleted ? (
              <motion.div
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button
                  size="lg"
                  onClick={handleCompleteRecipe}
                  className="gap-2 text-lg px-8 py-6 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600"
                >
                  <Trophy className="size-6" />
                  Complete Recipe & Earn {recipe.xpReward} XP
                </Button>
              </motion.div>
            ) : (
              <div className="space-y-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  className="inline-flex items-center gap-2 bg-green-500 text-white px-6 py-3 rounded-full"
                >
                  <CheckCircle2 className="size-6" />
                  <span className="font-bold text-lg">Recipe Completed!</span>
                </motion.div>
                <p className="text-muted-foreground">
                  You've already earned {recipe.xpReward} XP from this recipe
                </p>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
