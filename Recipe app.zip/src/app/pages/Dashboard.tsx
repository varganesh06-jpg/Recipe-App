import { useState } from "react";
import { Link } from "react-router";
import { motion } from "motion/react";
import { useAuth } from "../context/AuthContext";
import { recipes } from "../data/recipes-new";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { Progress } from "../components/ui/progress";
import { Badge } from "../components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs";
import {
  ChefHat,
  Trophy,
  Flame,
  Zap,
  Star,
  Clock,
  Filter,
  LogOut,
  Award
} from "lucide-react";
import { AnimatedRecipeCard } from "../components/AnimatedRecipeCard";
import { UserStats } from "../components/UserStats";
import { courseTypes, cuisines, dietTypes, difficulties } from "../data/recipes-new";

const XP_PER_LEVEL = 500;

export function Dashboard() {
  const { user, logout } = useAuth();
  const [selectedCourse, setSelectedCourse] = useState<string>("All");
  const [selectedCuisine, setSelectedCuisine] = useState<string>("All");
  const [selectedDiet, setSelectedDiet] = useState<string>("All");
  const [selectedTime, setSelectedTime] = useState<string>("All");
  const [showFilters, setShowFilters] = useState(false);

  if (!user) return null;

  const filteredRecipes = recipes.filter((recipe) => {
    if (selectedCourse !== "All" && recipe.courseType !== selectedCourse) return false;
    if (selectedCuisine !== "All" && recipe.cuisine !== selectedCuisine) return false;
    if (selectedDiet !== "All" && !recipe.dietType.includes(selectedDiet as any)) return false;
    if (selectedTime !== "All") {
      if (selectedTime === "5min" && recipe.time > 5) return false;
      if (selectedTime === "10min" && recipe.time > 10) return false;
      if (selectedTime === "30min" && recipe.time > 30) return false;
    }
    return true;
  });

  const quickRecipes = recipes.filter(r => r.time <= 10);
  const completedRecipesData = recipes.filter(r => user.completedRecipes.includes(r.id));
  const xpProgress = (user.xp / XP_PER_LEVEL) * 100;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-orange-50 dark:from-slate-950 dark:to-orange-950/20">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/dashboard" className="flex items-center gap-2">
              <motion.div
                animate={{ rotate: [0, 10, -10, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <ChefHat className="size-8 text-orange-600" />
              </motion.div>
              <span className="text-2xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
                Recipe Quest
              </span>
            </Link>

            <div className="flex items-center gap-4">
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="hidden md:flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-500 to-amber-500 rounded-full text-white"
              >
                <Flame className="size-5" />
                <span className="font-bold">{user.streak} Day Streak</span>
              </motion.div>

              <UserStats />

              <Button variant="ghost" size="icon" onClick={logout}>
                <LogOut className="size-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* User Stats Section */}
        <motion.div
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card className="bg-gradient-to-br from-purple-500 to-purple-700 text-white border-none">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Level</p>
                    <p className="text-4xl font-bold">{user.level}</p>
                  </div>
                  <Trophy className="size-12 opacity-80" />
                </div>
                <div className="mt-4">
                  <Progress value={xpProgress} className="h-2 bg-purple-300" />
                  <p className="text-xs mt-1 opacity-90">{user.xp} / {XP_PER_LEVEL} XP</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-red-600 text-white border-none">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Streak</p>
                    <p className="text-4xl font-bold">{user.streak}</p>
                  </div>
                  <Flame className="size-12 opacity-80" />
                </div>
                <p className="text-sm mt-4 opacity-90">Days cooking!</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500 to-emerald-600 text-white border-none">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Completed</p>
                    <p className="text-4xl font-bold">{user.completedRecipes.length}</p>
                  </div>
                  <Star className="size-12 opacity-80" />
                </div>
                <p className="text-sm mt-4 opacity-90">Recipes mastered</p>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500 to-cyan-600 text-white border-none">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm opacity-90">Achievements</p>
                    <p className="text-4xl font-bold">{user.achievements.length}</p>
                  </div>
                  <Award className="size-12 opacity-80" />
                </div>
                <p className="text-sm mt-4 opacity-90">Unlocked</p>
              </CardContent>
            </Card>
          </div>

          {/* Achievements Bar */}
          <Card className="overflow-hidden">
            <CardContent className="p-4">
              <div className="flex items-center gap-3 overflow-x-auto">
                <Trophy className="size-6 text-yellow-600 flex-shrink-0" />
                <div className="flex gap-2 flex-wrap">
                  {user.achievements.map((achievement, idx) => (
                    <motion.div
                      key={achievement}
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: idx * 0.1 }}
                    >
                      <Badge variant="secondary" className="gap-1">
                        <Star className="size-3 fill-yellow-500 text-yellow-500" />
                        {achievement}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Access Buttons */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Zap className="size-6 text-orange-600" />
            Quick Recipes
          </h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            <Button
              variant={selectedTime === "5min" ? "default" : "outline"}
              onClick={() => setSelectedTime(selectedTime === "5min" ? "All" : "5min")}
              className="gap-2 whitespace-nowrap"
            >
              <Clock className="size-4" />5 Minutes
            </Button>
            <Button
              variant={selectedTime === "10min" ? "default" : "outline"}
              onClick={() => setSelectedTime(selectedTime === "10min" ? "All" : "10min")}
              className="gap-2 whitespace-nowrap"
            >
              <Clock className="size-4" />10 Minutes
            </Button>
            <Button
              variant={selectedTime === "30min" ? "default" : "outline"}
              onClick={() => setSelectedTime(selectedTime === "30min" ? "All" : "30min")}
              className="gap-2 whitespace-nowrap"
            >
              <Clock className="size-4" />30 Minutes
            </Button>
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="gap-2 whitespace-nowrap"
            >
              <Filter className="size-4" />
              {showFilters ? "Hide" : "More"} Filters
            </Button>
          </div>

          {showFilters && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="mt-4 p-4 bg-muted/50 rounded-lg space-y-4"
            >
              <div>
                <p className="text-sm font-medium mb-2">Course Type</p>
                <div className="flex flex-wrap gap-2">
                  <Badge
                    variant={selectedCourse === "All" ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setSelectedCourse("All")}
                  >
                    All
                  </Badge>
                  {courseTypes.map((type) => (
                    <Badge
                      key={type}
                      variant={selectedCourse === type ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setSelectedCourse(type)}
                    >
                      {type}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Cuisine</p>
                <div className="flex flex-wrap gap-2">
                  <Badge
                    variant={selectedCuisine === "All" ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setSelectedCuisine("All")}
                  >
                    All
                  </Badge>
                  {cuisines.slice(0, 10).map((cuisine) => (
                    <Badge
                      key={cuisine}
                      variant={selectedCuisine === cuisine ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setSelectedCuisine(cuisine)}
                    >
                      {cuisine}
                    </Badge>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-sm font-medium mb-2">Diet Type</p>
                <div className="flex flex-wrap gap-2">
                  <Badge
                    variant={selectedDiet === "All" ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setSelectedDiet("All")}
                  >
                    All
                  </Badge>
                  {dietTypes.map((diet) => (
                    <Badge
                      key={diet}
                      variant={selectedDiet === diet ? "default" : "outline"}
                      className="cursor-pointer"
                      onClick={() => setSelectedDiet(diet)}
                    >
                      {diet}
                    </Badge>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="all" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto">
            <TabsTrigger value="all">All Recipes</TabsTrigger>
            <TabsTrigger value="quick">Quick & Easy</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredRecipes.map((recipe, idx) => (
                <AnimatedRecipeCard key={recipe.id} recipe={recipe} delay={idx * 0.1} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="quick" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {quickRecipes.map((recipe, idx) => (
                <AnimatedRecipeCard key={recipe.id} recipe={recipe} delay={idx * 0.1} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="completed" className="space-y-4">
            {completedRecipesData.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {completedRecipesData.map((recipe, idx) => (
                  <AnimatedRecipeCard
                    key={recipe.id}
                    recipe={recipe}
                    delay={idx * 0.1}
                    completed
                  />
                ))}
              </div>
            ) : (
              <Card className="p-12 text-center">
                <ChefHat className="size-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-xl font-semibold mb-2">No recipes completed yet</h3>
                <p className="text-muted-foreground mb-4">
                  Start cooking to earn XP and level up!
                </p>
                <Button onClick={() => document.querySelector('[value="all"]')?.dispatchEvent(new Event('click', { bubbles: true }))}>
                  Browse Recipes
                </Button>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}