import { useParams, Link, useNavigate } from "react-router";
import { recipes } from "../data/recipes";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Separator } from "../components/ui/separator";
import { ArrowLeft, Clock, Users, ChefHat } from "lucide-react";

export function RecipeDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const recipe = recipes.find((r) => r.id === id);

  if (!recipe) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-4">Recipe Not Found</h1>
          <Link to="/recipes">
            <Button>Back to Recipes</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur z-10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <ChefHat className="size-8 text-orange-600" />
            <span className="text-xl font-bold">Recipe App</span>
          </Link>
          <div className="flex gap-2">
            <Link to="/recipes">
              <Button variant="ghost">All Recipes</Button>
            </Link>
            <Link to="/">
              <Button variant="ghost">Home</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Button
          variant="ghost"
          className="mb-6 gap-2"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="size-4" />
          Back
        </Button>

        {/* Recipe Header */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-2 mb-4">
            <Badge variant="secondary">{recipe.category}</Badge>
            <Badge
              variant={
                recipe.difficulty === "Easy"
                  ? "default"
                  : recipe.difficulty === "Medium"
                  ? "secondary"
                  : "destructive"
              }
            >
              {recipe.difficulty}
            </Badge>
          </div>
          <h1 className="text-4xl font-bold mb-4">{recipe.title}</h1>
          <p className="text-xl text-muted-foreground">{recipe.description}</p>
        </div>

        {/* Recipe Image */}
        <div className="aspect-video rounded-lg overflow-hidden mb-8">
          <img
            src={recipe.image}
            alt={recipe.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Recipe Info */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="flex items-center gap-3 p-6">
              <Clock className="size-8 text-orange-600" />
              <div>
                <p className="text-sm text-muted-foreground">Prep Time</p>
                <p className="font-semibold">{recipe.time} minutes</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-3 p-6">
              <Users className="size-8 text-orange-600" />
              <div>
                <p className="text-sm text-muted-foreground">Servings</p>
                <p className="font-semibold">{recipe.servings} people</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="flex items-center gap-3 p-6">
              <ChefHat className="size-8 text-orange-600" />
              <div>
                <p className="text-sm text-muted-foreground">Difficulty</p>
                <p className="font-semibold">{recipe.difficulty}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Ingredients */}
          <Card>
            <CardHeader>
              <CardTitle>Ingredients</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {recipe.ingredients.map((ingredient, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <div className="size-2 rounded-full bg-orange-600 mt-2 flex-shrink-0" />
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Instructions */}
          <Card>
            <CardHeader>
              <CardTitle>Instructions</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-4">
                {recipe.instructions.map((instruction, index) => (
                  <li key={index} className="flex gap-4">
                    <span className="font-bold text-orange-600 flex-shrink-0">
                      {index + 1}.
                    </span>
                    <span>{instruction}</span>
                  </li>
                ))}
              </ol>
            </CardContent>
          </Card>
        </div>

        {/* More Recipes Section */}
        <Separator className="my-12" />
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-4">Want to try more recipes?</h2>
          <Link to="/recipes">
            <Button size="lg">Browse All Recipes</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
