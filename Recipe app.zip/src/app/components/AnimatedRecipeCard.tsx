import { Link } from "react-router";
import { motion } from "motion/react";
import { Card, CardContent, CardFooter } from "./ui/card";
import { Badge } from "./ui/badge";
import { Clock, Users, Trophy, Flame, Sparkles } from "lucide-react";
import type { Recipe } from "../data/recipes-new";

interface AnimatedRecipeCardProps {
  recipe: Recipe;
  delay?: number;
  completed?: boolean;
}

export function AnimatedRecipeCard({ recipe, delay = 0, completed = false }: AnimatedRecipeCardProps) {
  const difficultyColors = {
    "Beginner": "default",
    "Intermediate": "secondary",
    "Advanced": "destructive",
    "5-Star Chef": "destructive"
  } as const;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        duration: 0.4,
        delay,
        ease: "easeOut"
      }}
      whileHover={{ y: -8, transition: { duration: 0.2 } }}
    >
      <Link to={`/recipe/${recipe.id}`} className="block group">
        <Card className="overflow-hidden h-full relative transition-shadow duration-300 hover:shadow-2xl">
          {completed && (
            <div className="absolute top-3 right-3 z-10">
              <motion.div
                initial={{ scale: 0, rotate: -180 }}
                animate={{ scale: 1, rotate: 0 }}
                transition={{ delay: delay + 0.3 }}
                className="bg-green-500 text-white p-2 rounded-full shadow-lg"
              >
                <Trophy className="size-5" />
              </motion.div>
            </div>
          )}
          
          <div className="aspect-video overflow-hidden relative">
            <motion.img
              src={recipe.image}
              alt={recipe.title}
              className="w-full h-full object-cover"
              whileHover={{ scale: 1.1 }}
              transition={{ duration: 0.4 }}
            />
            
            {/* XP Badge */}
            <motion.div
              className="absolute top-3 left-3 bg-gradient-to-r from-purple-600 to-purple-800 text-white px-3 py-1 rounded-full flex items-center gap-1 shadow-lg"
              whileHover={{ scale: 1.1 }}
            >
              <Sparkles className="size-4" />
              <span className="font-bold text-sm">+{recipe.xpReward} XP</span>
            </motion.div>

            {/* Quick Recipe Indicator */}
            {recipe.time <= 10 && (
              <motion.div
                className="absolute bottom-3 right-3 bg-orange-500 text-white px-3 py-1 rounded-full flex items-center gap-1 shadow-lg"
                animate={{
                  scale: [1, 1.1, 1],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              >
                <Flame className="size-4" />
                <span className="font-bold text-sm">Quick!</span>
              </motion.div>
            )}

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          </div>

          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <Badge variant="secondary" className="text-xs">
                {recipe.courseType}
              </Badge>
              <Badge variant={difficultyColors[recipe.difficulty]} className="text-xs">
                {recipe.difficulty}
              </Badge>
              {recipe.dietType.slice(0, 1).map((diet) => (
                <Badge key={diet} variant="outline" className="text-xs">
                  {diet}
                </Badge>
              ))}
            </div>
            
            <h3 className="font-semibold mb-2 line-clamp-1 group-hover:text-orange-600 transition-colors">
              {recipe.title}
            </h3>
            
            <p className="text-sm text-muted-foreground line-clamp-2 mb-3">
              {recipe.description}
            </p>

            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className="text-xs">
                🌍 {recipe.cuisine}
              </Badge>
            </div>
          </CardContent>

          <CardFooter className="p-4 pt-0 flex items-center justify-between text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Clock className="size-4 text-orange-600" />
              <span className="font-medium">{recipe.time} min</span>
            </div>
            <div className="flex items-center gap-1">
              <Users className="size-4 text-orange-600" />
              <span className="font-medium">{recipe.servings}</span>
            </div>
            {recipe.calories && (
              <div className="text-xs">
                <span className="font-medium">{recipe.calories} cal</span>
              </div>
            )}
          </CardFooter>

          {/* Hover Effect Border */}
          <motion.div
            className="absolute inset-0 border-2 border-orange-500 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
            initial={false}
          />
        </Card>
      </Link>
    </motion.div>
  );
}
