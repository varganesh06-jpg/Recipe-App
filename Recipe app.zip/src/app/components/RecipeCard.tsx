import { Link } from "react-router";
import { Card, CardContent, CardFooter } from "./ui/card";
import { Badge } from "./ui/badge";
import { Clock, Users } from "lucide-react";
import type { Recipe } from "../data/recipes";

interface RecipeCardProps {
  recipe: Recipe;
}

export function RecipeCard({ recipe }: RecipeCardProps) {
  return (
    <Link to={`/recipe/${recipe.id}`} className="block group">
      <Card className="overflow-hidden h-full transition-transform duration-200 group-hover:scale-[1.02]">
        <div className="aspect-video overflow-hidden">
          <img
            src={recipe.image}
            alt={recipe.title}
            className="w-full h-full object-cover transition-transform duration-200 group-hover:scale-110"
          />
        </div>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-2">
            <Badge variant="secondary">{recipe.category}</Badge>
            <Badge
              variant={
                recipe.difficulty === "Easy"
                  ? "default"
                  : recipe.difficulty === "Medium"
                  ? "secondary"
                  : "destructive"
              }
            >
              {recipe.difficulty}
            </Badge>
          </div>
          <h3 className="font-semibold mb-2 line-clamp-1">{recipe.title}</h3>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {recipe.description}
          </p>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Clock className="size-4" />
            <span>{recipe.time} min</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="size-4" />
            <span>{recipe.servings} servings</span>
          </div>
        </CardFooter>
      </Card>
    </Link>
  );
}
