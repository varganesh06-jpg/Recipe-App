import { motion } from "motion/react";
import { useAuth } from "../context/AuthContext";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "./ui/dialog";
import { Button } from "./ui/button";
import { Card, CardContent } from "./ui/card";
import { Badge } from "./ui/badge";
import { Progress } from "./ui/progress";
import { User, Trophy, Star, Flame, Target, Award } from "lucide-react";

const XP_PER_LEVEL = 500;

export function UserStats() {
  const { user } = useAuth();

  if (!user) return null;

  const xpProgress = (user.xp / XP_PER_LEVEL) * 100;
  const nextLevelXp = XP_PER_LEVEL - user.xp;

  const allAchievements = [
    { id: "beginner", name: "Beginner Chef", icon: "🏆", unlocked: user.achievements.includes("Beginner Chef") },
    { id: "5recipes", name: "First 5 Recipes", icon: "⭐", unlocked: user.achievements.includes("First 5 Recipes") },
    { id: "master", name: "Recipe Master", icon: "👨‍🍳", unlocked: user.achievements.includes("Recipe Master") },
    { id: "level5", name: "Level 5 Chef", icon: "🔥", unlocked: user.achievements.includes("Level 5 Chef") },
    { id: "week", name: "Week Warrior", icon: "💪", unlocked: user.achievements.includes("Week Warrior") },
    { id: "gourmet", name: "Gourmet Explorer", icon: "🌟", unlocked: false },
    { id: "speedster", name: "Speed Chef", icon: "⚡", unlocked: false },
    { id: "perfectionist", name: "Perfectionist", icon: "💎", unlocked: false },
  ];

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <User className="size-5" />
          <motion.div
            className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs rounded-full size-5 flex items-center justify-center font-bold"
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {user.level}
          </motion.div>
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl flex items-center gap-2">
            <User className="size-6 text-orange-600" />
            {user.username}'s Profile
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Level Progress */}
          <Card className="bg-gradient-to-r from-purple-500 to-purple-700 text-white border-none">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm opacity-90">Current Level</p>
                  <p className="text-5xl font-bold">{user.level}</p>
                </div>
                <Trophy className="size-16 opacity-80" />
              </div>
              <Progress value={xpProgress} className="h-3 bg-purple-300 mb-2" />
              <div className="flex justify-between text-sm">
                <span>{user.xp} XP</span>
                <span>{nextLevelXp} XP to Level {user.level + 1}</span>
              </div>
            </CardContent>
          </Card>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="bg-orange-100 dark:bg-orange-950/50 p-3 rounded-full">
                  <Flame className="size-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Streak</p>
                  <p className="text-2xl font-bold">{user.streak} days</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="bg-green-100 dark:bg-green-950/50 p-3 rounded-full">
                  <Target className="size-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold">{user.completedRecipes.length}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="bg-blue-100 dark:bg-blue-950/50 p-3 rounded-full">
                  <Star className="size-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Total XP</p>
                  <p className="text-2xl font-bold">{user.totalXp}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-4 flex items-center gap-3">
                <div className="bg-yellow-100 dark:bg-yellow-950/50 p-3 rounded-full">
                  <Award className="size-6 text-yellow-600" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Achievements</p>
                  <p className="text-2xl font-bold">{user.achievements.length}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Achievements */}
          <div>
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <Trophy className="size-5 text-yellow-600" />
              Achievements
            </h3>
            <div className="grid grid-cols-2 gap-3">
              {allAchievements.map((achievement, idx) => (
                <motion.div
                  key={achievement.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: idx * 0.05 }}
                >
                  <Card className={achievement.unlocked ? "border-yellow-500" : "opacity-50"}>
                    <CardContent className="p-4 flex items-center gap-3">
                      <div className="text-3xl">{achievement.icon}</div>
                      <div className="flex-1">
                        <p className="font-medium text-sm">{achievement.name}</p>
                        {achievement.unlocked ? (
                          <Badge variant="secondary" className="mt-1 text-xs">
                            Unlocked
                          </Badge>
                        ) : (
                          <Badge variant="outline" className="mt-1 text-xs">
                            Locked
                          </Badge>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Account Info */}
          <Card>
            <CardContent className="p-4">
              <p className="text-sm text-muted-foreground mb-1">Username</p>
              <p className="font-semibold">{user.username}</p>
              <p className="text-xs text-muted-foreground mt-2">
                Member since {new Date(user.lastLoginDate).toLocaleDateString()}
              </p>
            </CardContent>
          </Card>
        </div>
      </DialogContent>
    </Dialog>
  );
}
