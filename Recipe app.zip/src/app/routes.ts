import { createBrowserRouter } from "react-router";
import { Home } from "./pages/Home";
import { Recipes } from "./pages/Recipes";
import { RecipeDetail } from "./pages/RecipeDetail";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/recipes",
    Component: Recipes,
  },
  {
    path: "/recipe/:id",
    Component: RecipeDetail,
  },
  {
    path: "*",
    Component: NotFound,
  },
]);
