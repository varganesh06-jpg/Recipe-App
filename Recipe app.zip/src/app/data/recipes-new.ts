export interface Recipe {
  id: string;
  title: string;
  description: string;
  image: string;
  
  // Primary Categories
  courseType: CourseType;
  cuisine: Cuisine;
  dietType: DietType[];
  cookingMethod: CookingMethod;
  difficulty: Difficulty;
  occasion: Occasion[];
  
  // Details
  time: number; // in minutes
  servings: number;
  calories?: number;
  xpReward: number; // gamification points
  
  ingredients: string[];
  instructions: string[];
}

export type CourseType =
  | "Appetizers"
  | "Soups"
  | "Salads"
  | "Main Course"
  | "Side Dishes"
  | "Rice & Grains"
  | "Breads"
  | "Noodles & Pasta"
  | "Snacks & Street Food"
  | "Desserts"
  | "Beverages"
  | "Sauces & Condiments";

export type Cuisine =
  | "Indian"
  | "Tamil Nadu Traditional"
  | "Chinese"
  | "Japanese"
  | "Korean"
  | "Thai"
  | "Vietnamese"
  | "Indonesian"
  | "Malaysian"
  | "Italian"
  | "French"
  | "Spanish"
  | "Greek"
  | "German"
  | "British"
  | "Turkish"
  | "North American"
  | "Mexican"
  | "Brazilian"
  | "Caribbean"
  | "Arabic"
  | "Persian"
  | "Moroccan"
  | "Ethiopian"
  | "Egyptian"
  | "Lebanese";

export type DietType =
  | "Vegetarian"
  | "Vegan"
  | "Eggitarian"
  | "Non-Vegetarian"
  | "Gluten-Free"
  | "Keto"
  | "Low-Carb"
  | "High-Protein"
  | "Dairy-Free";

export type CookingMethod =
  | "Frying"
  | "Baking"
  | "Grilling"
  | "Steaming"
  | "Boiling"
  | "Pressure Cooking"
  | "Air Frying"
  | "Slow Cooking"
  | "No-Cook";

export type Difficulty =
  | "Beginner"
  | "Intermediate"
  | "Advanced"
  | "5-Star Chef";

export type Occasion =
  | "Breakfast"
  | "Lunch"
  | "Dinner"
  | "Brunch"
  | "Evening Snacks"
  | "Festival Specials"
  | "Party Food"
  | "Kids Friendly"
  | "Weight Loss"
  | "Healthy Living"
  | "Comfort Food";

export const recipes: Recipe[] = [
  // Quick 5-10 min dishes
  {
    id: "1",
    title: "Quick Veggie Sandwich",
    description: "Fresh and healthy sandwich ready in 5 minutes",
    image: "https://images.unsplash.com/photo-1762336108575-83555d78b432?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxxdWljayUyMHNhbmR3aWNoJTIwaGVhbHRoeXxlbnwxfHx8fDE3NzIwMzkzOTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Snacks & Street Food",
    cuisine: "North American",
    dietType: ["Vegetarian"],
    cookingMethod: "No-Cook",
    difficulty: "Beginner",
    occasion: ["Breakfast", "Evening Snacks", "Kids Friendly", "Healthy Living"],
    time: 5,
    servings: 2,
    calories: 250,
    xpReward: 50,
    ingredients: [
      "4 bread slices",
      "1 tomato, sliced",
      "1 cucumber, sliced",
      "Lettuce leaves",
      "2 tbsp mayo or mustard",
      "Salt and pepper"
    ],
    instructions: [
      "Toast bread slices if desired",
      "Spread mayo or mustard on bread",
      "Layer lettuce, tomato, and cucumber",
      "Season with salt and pepper",
      "Top with another bread slice and serve"
    ]
  },
  {
    id: "2",
    title: "Instant Berry Smoothie",
    description: "Refreshing smoothie packed with antioxidants",
    image: "https://images.unsplash.com/photo-1655992590262-aeadeef445b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcnVpdCUyMHNtb290aGllJTIwZHJpbmt8ZW58MXx8fHwxNzcyMDM5MzkxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Beverages",
    cuisine: "North American",
    dietType: ["Vegan", "Vegetarian", "Gluten-Free", "Dairy-Free"],
    cookingMethod: "No-Cook",
    difficulty: "Beginner",
    occasion: ["Breakfast", "Healthy Living", "Weight Loss"],
    time: 5,
    servings: 2,
    calories: 180,
    xpReward: 50,
    ingredients: [
      "1 cup mixed berries",
      "1 banana",
      "1 cup almond milk",
      "1 tbsp honey",
      "Ice cubes"
    ],
    instructions: [
      "Add all ingredients to blender",
      "Blend until smooth",
      "Pour into glasses",
      "Serve immediately"
    ]
  },
  {
    id: "3",
    title: "2-Minute Instant Noodles Upgrade",
    description: "Transform instant noodles into a gourmet meal",
    image: "https://images.unsplash.com/photo-1761125065373-05a8e2f85cd5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbnN0YW50JTIwbm9vZGxlcyUyMGJvd2x8ZW58MXx8fHwxNzcyMDM5MzkwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Noodles & Pasta",
    cuisine: "Japanese",
    dietType: ["Vegetarian"],
    cookingMethod: "Boiling",
    difficulty: "Beginner",
    occasion: ["Lunch", "Dinner", "Evening Snacks", "Kids Friendly"],
    time: 5,
    servings: 1,
    calories: 380,
    xpReward: 50,
    ingredients: [
      "1 pack instant noodles",
      "1 egg",
      "Green onions, chopped",
      "Chili flakes",
      "Sesame oil"
    ],
    instructions: [
      "Boil water and cook noodles for 2 minutes",
      "Add egg in the last minute",
      "Mix in seasoning packet",
      "Top with green onions, chili flakes, and sesame oil",
      "Serve hot"
    ]
  },
  {
    id: "4",
    title: "Classic Avocado Toast",
    description: "Creamy avocado on crispy sourdough",
    image: "https://images.unsplash.com/photo-1604634077134-6f774f610f47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGJyZWFrZmFzdCUyMGF2b2NhZG8lMjB0b2FzdHxlbnwxfHx8fDE3NzIwMzQ4NDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Snacks & Street Food",
    cuisine: "North American",
    dietType: ["Vegetarian", "Vegan"],
    cookingMethod: "No-Cook",
    difficulty: "Beginner",
    occasion: ["Breakfast", "Brunch", "Healthy Living"],
    time: 10,
    servings: 2,
    calories: 300,
    xpReward: 75,
    ingredients: [
      "2 slices sourdough bread",
      "1 ripe avocado",
      "Lemon juice",
      "Red pepper flakes",
      "Salt and pepper",
      "Cherry tomatoes"
    ],
    instructions: [
      "Toast bread until golden",
      "Mash avocado with lemon juice, salt, and pepper",
      "Spread on toast",
      "Top with cherry tomatoes and red pepper flakes",
      "Serve immediately"
    ]
  },
  {
    id: "5",
    title: "Hummus Appetizer Bowl",
    description: "Creamy Mediterranean dip with fresh vegetables",
    image: "https://images.unsplash.com/photo-1633984927681-52b4e54f40ca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlayUyMGh1bW11cyUyMGFwcGV0aXplcnxlbnwxfHx8fDE3NzIwMzkzOTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Appetizers",
    cuisine: "Greek",
    dietType: ["Vegan", "Vegetarian", "Gluten-Free"],
    cookingMethod: "No-Cook",
    difficulty: "Beginner",
    occasion: ["Party Food", "Healthy Living"],
    time: 10,
    servings: 4,
    calories: 150,
    xpReward: 75,
    ingredients: [
      "1 can chickpeas",
      "3 tbsp tahini",
      "2 garlic cloves",
      "Lemon juice",
      "Olive oil",
      "Paprika",
      "Vegetables for dipping"
    ],
    instructions: [
      "Blend chickpeas, tahini, garlic, and lemon juice",
      "Add water to achieve smooth consistency",
      "Transfer to serving bowl",
      "Drizzle with olive oil and sprinkle paprika",
      "Serve with fresh vegetables"
    ]
  },
  {
    id: "6",
    title: "Fresh Guacamole",
    description: "Authentic Mexican avocado dip",
    image: "https://images.unsplash.com/photo-1701203236447-89a7016a5a40?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZXhpY2FuJTIwZ3VhY2Ftb2xlJTIwZGlwfGVufDF8fHx8MTc3MjAzOTM5Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Sauces & Condiments",
    cuisine: "Mexican",
    dietType: ["Vegan", "Vegetarian", "Gluten-Free", "Keto"],
    cookingMethod: "No-Cook",
    difficulty: "Beginner",
    occasion: ["Party Food", "Evening Snacks"],
    time: 10,
    servings: 4,
    calories: 120,
    xpReward: 75,
    ingredients: [
      "3 ripe avocados",
      "1 lime, juiced",
      "1 tomato, diced",
      "1/4 onion, diced",
      "Cilantro, chopped",
      "Salt to taste"
    ],
    instructions: [
      "Mash avocados in a bowl",
      "Add lime juice immediately",
      "Mix in tomato, onion, and cilantro",
      "Season with salt",
      "Serve with tortilla chips"
    ]
  },
  // Intermediate dishes
  {
    id: "7",
    title: "Chicken Biryani",
    description: "Aromatic Indian rice dish with spiced chicken",
    image: "https://images.unsplash.com/photo-1666190092689-e3968aa0c32c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmRpYW4lMjBiaXJ5YW5pJTIwcmljZXxlbnwxfHx8fDE3NzE5NDcxMTF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Rice & Grains",
    cuisine: "Indian",
    dietType: ["Non-Vegetarian", "High-Protein"],
    cookingMethod: "Pressure Cooking",
    difficulty: "Intermediate",
    occasion: ["Lunch", "Dinner", "Festival Specials", "Party Food"],
    time: 45,
    servings: 6,
    calories: 450,
    xpReward: 150,
    ingredients: [
      "500g chicken",
      "2 cups basmati rice",
      "1 cup yogurt",
      "2 onions, sliced",
      "Biryani masala",
      "Saffron",
      "Mint and cilantro",
      "Ghee"
    ],
    instructions: [
      "Marinate chicken with yogurt and spices for 30 minutes",
      "Fry onions until golden brown",
      "Cook rice until 70% done",
      "Layer rice and chicken in pressure cooker",
      "Add saffron milk and fried onions",
      "Cook for 15 minutes on low heat",
      "Let it rest for 10 minutes before serving"
    ]
  },
  {
    id: "8",
    title: "French Butter Croissants",
    description: "Flaky, buttery pastries perfect for breakfast",
    image: "https://images.unsplash.com/photo-1705856987588-1e6ae0b6061f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVuY2glMjBjcm9pc3NhbnQlMjBicmVha2Zhc3R8ZW58MXx8fHwxNzcyMDIyNjY3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Breads",
    cuisine: "French",
    dietType: ["Vegetarian", "Eggitarian"],
    cookingMethod: "Baking",
    difficulty: "Advanced",
    occasion: ["Breakfast", "Brunch"],
    time: 180,
    servings: 8,
    calories: 280,
    xpReward: 250,
    ingredients: [
      "500g all-purpose flour",
      "300g cold butter",
      "10g salt",
      "50g sugar",
      "10g instant yeast",
      "250ml milk",
      "1 egg for wash"
    ],
    instructions: [
      "Make dough with flour, yeast, sugar, salt, and milk",
      "Rest dough for 1 hour",
      "Roll out and fold with butter (lamination)",
      "Repeat folding 3 times with 30-min rests",
      "Cut into triangles and roll into crescents",
      "Proof for 2 hours",
      "Brush with egg wash",
      "Bake at 200°C for 20 minutes"
    ]
  },
  {
    id: "9",
    title: "Japanese Sushi Rolls",
    description: "Fresh sushi with vegetables and seafood",
    image: "https://images.unsplash.com/photo-1712183718471-dab51f0748ac?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxqYXBhbmVzZSUyMHN1c2hpJTIwcm9sbHN8ZW58MXx8fHwxNzcxOTUzODU2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Main Course",
    cuisine: "Japanese",
    dietType: ["Non-Vegetarian", "High-Protein", "Gluten-Free"],
    cookingMethod: "No-Cook",
    difficulty: "Intermediate",
    occasion: ["Lunch", "Dinner", "Party Food", "Healthy Living"],
    time: 30,
    servings: 4,
    calories: 320,
    xpReward: 150,
    ingredients: [
      "2 cups sushi rice",
      "Nori sheets",
      "Fresh fish (salmon, tuna)",
      "Cucumber",
      "Avocado",
      "Rice vinegar",
      "Soy sauce",
      "Wasabi"
    ],
    instructions: [
      "Cook sushi rice and season with rice vinegar",
      "Place nori on bamboo mat",
      "Spread rice evenly on nori",
      "Add fish, cucumber, and avocado in a line",
      "Roll tightly using the mat",
      "Slice into 8 pieces",
      "Serve with soy sauce and wasabi"
    ]
  },
  {
    id: "10",
    title: "Pad Thai Noodles",
    description: "Thailand's famous street food noodles",
    image: "https://images.unsplash.com/photo-1729708475167-71a6eb3cd741?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0aGFpJTIwcGFkJTIwdGhhaXxlbnwxfHx8fDE3NzIwMzkzODl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Noodles & Pasta",
    cuisine: "Thai",
    dietType: ["Non-Vegetarian", "High-Protein"],
    cookingMethod: "Frying",
    difficulty: "Intermediate",
    occasion: ["Lunch", "Dinner", "Snacks & Street Food"],
    time: 25,
    servings: 4,
    calories: 400,
    xpReward: 125,
    ingredients: [
      "200g rice noodles",
      "200g shrimp or chicken",
      "2 eggs",
      "Bean sprouts",
      "Peanuts, crushed",
      "Tamarind paste",
      "Fish sauce",
      "Lime wedges"
    ],
    instructions: [
      "Soak rice noodles in warm water",
      "Stir-fry protein until cooked",
      "Push to side and scramble eggs",
      "Add drained noodles",
      "Mix in tamarind paste and fish sauce",
      "Add bean sprouts and toss",
      "Garnish with peanuts and lime"
    ]
  },
  {
    id: "11",
    title: "Turkish Kebab Platter",
    description: "Grilled meat skewers with aromatic spices",
    image: "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0dXJraXNoJTIwa2ViYWJ8ZW58MXx8fHwxNzcyMDM5Mzg5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Main Course",
    cuisine: "Turkish",
    dietType: ["Non-Vegetarian", "High-Protein", "Keto"],
    cookingMethod: "Grilling",
    difficulty: "Intermediate",
    occasion: ["Lunch", "Dinner", "Party Food"],
    time: 35,
    servings: 4,
    calories: 380,
    xpReward: 150,
    ingredients: [
      "500g lamb or beef",
      "2 onions, grated",
      "Cumin powder",
      "Paprika",
      "Garlic",
      "Yogurt",
      "Pita bread",
      "Fresh herbs"
    ],
    instructions: [
      "Marinate meat with spices, onion, and yogurt for 2 hours",
      "Thread meat onto skewers",
      "Preheat grill to medium-high",
      "Grill for 10-12 minutes, turning occasionally",
      "Let rest for 5 minutes",
      "Serve with pita bread and fresh herbs"
    ]
  },
  {
    id: "12",
    title: "Korean Bibimbap Bowl",
    description: "Colorful rice bowl with vegetables and egg",
    image: "https://images.unsplash.com/photo-1741295017668-c8132acd6fc0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxrb3JlYW4lMjBiaWJpbWJhcCUyMGJvd2x8ZW58MXx8fHwxNzcxOTYwMTYxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Main Course",
    cuisine: "Korean",
    dietType: ["Vegetarian", "Eggitarian", "High-Protein"],
    cookingMethod: "Frying",
    difficulty: "Intermediate",
    occasion: ["Lunch", "Dinner", "Healthy Living"],
    time: 30,
    servings: 4,
    calories: 420,
    xpReward: 150,
    ingredients: [
      "2 cups rice",
      "Assorted vegetables (carrots, spinach, mushrooms)",
      "4 eggs",
      "Gochujang sauce",
      "Sesame oil",
      "Soy sauce",
      "Sesame seeds"
    ],
    instructions: [
      "Cook rice and keep warm",
      "Sauté each vegetable separately with garlic",
      "Fry eggs sunny-side up",
      "Divide rice into bowls",
      "Arrange vegetables in sections on rice",
      "Top with fried egg",
      "Serve with gochujang and sesame oil"
    ]
  },
  // Previous recipes adapted
  {
    id: "13",
    title: "Classic Spaghetti Carbonara",
    description: "Traditional Italian pasta with eggs and pancetta",
    image: "https://images.unsplash.com/photo-1632778129004-f142ce499b3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpdGFsaWFuJTIwcGFzdGElMjBkaXNofGVufDF8fHx8MTc3MjAyNTgyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Noodles & Pasta",
    cuisine: "Italian",
    dietType: ["Non-Vegetarian", "Eggitarian"],
    cookingMethod: "Boiling",
    difficulty: "Intermediate",
    occasion: ["Lunch", "Dinner", "Comfort Food"],
    time: 25,
    servings: 4,
    calories: 520,
    xpReward: 125,
    ingredients: [
      "400g spaghetti",
      "200g pancetta",
      "4 eggs",
      "100g Pecorino cheese",
      "Black pepper",
      "Salt"
    ],
    instructions: [
      "Boil salted water and cook spaghetti",
      "Fry pancetta until crispy",
      "Whisk eggs with cheese and pepper",
      "Drain pasta, reserve pasta water",
      "Toss hot pasta with pancetta",
      "Remove from heat, add egg mixture",
      "Add pasta water to create creamy sauce"
    ]
  },
  {
    id: "14",
    title: "Grilled Salmon",
    description: "Perfectly grilled salmon with herbs",
    image: "https://images.unsplash.com/photo-1580959375944-abd7e991f971?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwc2FsbW9uJTIwZGlubmVyfGVufDF8fHx8MTc3MjAzMjA4OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Main Course",
    cuisine: "North American",
    dietType: ["Non-Vegetarian", "High-Protein", "Keto"],
    cookingMethod: "Grilling",
    difficulty: "Beginner",
    occasion: ["Lunch", "Dinner", "Healthy Living"],
    time: 20,
    servings: 2,
    calories: 340,
    xpReward: 100,
    ingredients: [
      "2 salmon fillets",
      "Olive oil",
      "Lemon",
      "Garlic",
      "Fresh dill",
      "Salt and pepper"
    ],
    instructions: [
      "Preheat grill to medium-high",
      "Season salmon with salt and pepper",
      "Brush with olive oil and minced garlic",
      "Place lemon slices on top",
      "Grill 4-5 minutes per side",
      "Garnish with fresh dill"
    ]
  },
  {
    id: "15",
    title: "Chocolate Lava Cake",
    description: "Decadent dessert with molten chocolate center",
    image: "https://images.unsplash.com/photo-1736840334919-aac2d5af73e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBkZXNzZXJ0JTIwY2FrZXxlbnwxfHx8fDE3NzIwMTMyNDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    courseType: "Desserts",
    cuisine: "French",
    dietType: ["Vegetarian", "Eggitarian"],
    cookingMethod: "Baking",
    difficulty: "Intermediate",
    occasion: ["Party Food", "Festival Specials"],
    time: 30,
    servings: 4,
    calories: 420,
    xpReward: 150,
    ingredients: [
      "100g dark chocolate",
      "100g butter",
      "2 eggs",
      "50g sugar",
      "30g flour",
      "Vanilla extract"
    ],
    instructions: [
      "Preheat oven to 200°C",
      "Melt chocolate and butter together",
      "Whisk eggs and sugar until fluffy",
      "Combine chocolate mixture with eggs",
      "Fold in flour gently",
      "Pour into greased ramekins",
      "Bake for 12 minutes",
      "Serve immediately"
    ]
  }
];

export const courseTypes: CourseType[] = [
  "Appetizers",
  "Soups",
  "Salads",
  "Main Course",
  "Side Dishes",
  "Rice & Grains",
  "Breads",
  "Noodles & Pasta",
  "Snacks & Street Food",
  "Desserts",
  "Beverages",
  "Sauces & Condiments"
];

export const cuisines: Cuisine[] = [
  "Indian",
  "Tamil Nadu Traditional",
  "Chinese",
  "Japanese",
  "Korean",
  "Thai",
  "Vietnamese",
  "Indonesian",
  "Malaysian",
  "Italian",
  "French",
  "Spanish",
  "Greek",
  "German",
  "British",
  "Turkish",
  "North American",
  "Mexican",
  "Brazilian",
  "Caribbean",
  "Arabic",
  "Persian",
  "Moroccan",
  "Ethiopian",
  "Egyptian",
  "Lebanese"
];

export const dietTypes: DietType[] = [
  "Vegetarian",
  "Vegan",
  "Eggitarian",
  "Non-Vegetarian",
  "Gluten-Free",
  "Keto",
  "Low-Carb",
  "High-Protein",
  "Dairy-Free"
];

export const difficulties: Difficulty[] = [
  "Beginner",
  "Intermediate",
  "Advanced",
  "5-Star Chef"
];

export const occasions: Occasion[] = [
  "Breakfast",
  "Lunch",
  "Dinner",
  "Brunch",
  "Evening Snacks",
  "Festival Specials",
  "Party Food",
  "Kids Friendly",
  "Weight Loss",
  "Healthy Living",
  "Comfort Food"
];
