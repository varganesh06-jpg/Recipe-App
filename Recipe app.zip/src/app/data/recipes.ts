export interface Recipe {
  id: string;
  title: string;
  description: string;
  image: string;
  category: string;
  time: number;
  servings: number;
  difficulty: "Easy" | "Medium" | "Hard";
  ingredients: string[];
  instructions: string[];
}

export const recipes: Recipe[] = [
  {
    id: "1",
    title: "Classic Spaghetti Carbonara",
    description: "Traditional Italian pasta with eggs, cheese, and pancetta",
    image: "https://images.unsplash.com/photo-1632778129004-f142ce499b3e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpdGFsaWFuJTIwcGFzdGElMjBkaXNofGVufDF8fHx8MTc3MjAyNTgyOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Italian",
    time: 25,
    servings: 4,
    difficulty: "Medium",
    ingredients: [
      "400g spaghetti",
      "200g pancetta or guanciale, diced",
      "4 large eggs",
      "100g Pecorino Romano cheese, grated",
      "Black pepper to taste",
      "Salt for pasta water"
    ],
    instructions: [
      "Bring a large pot of salted water to boil and cook spaghetti according to package directions.",
      "While pasta cooks, fry pancetta in a large pan over medium heat until crispy.",
      "In a bowl, whisk together eggs, grated cheese, and black pepper.",
      "Drain pasta, reserving 1 cup of pasta water.",
      "Remove pan from heat, add hot pasta to pancetta and toss.",
      "Quickly stir in egg mixture, adding pasta water as needed to create a creamy sauce.",
      "Serve immediately with extra cheese and pepper."
    ]
  },
  {
    id: "2",
    title: "Grilled Salmon with Lemon",
    description: "Perfectly grilled salmon fillet with fresh herbs and lemon",
    image: "https://images.unsplash.com/photo-1580959375944-abd7e991f971?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmlsbGVkJTIwc2FsbW9uJTIwZGlubmVyfGVufDF8fHx8MTc3MjAzMjA4OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Seafood",
    time: 20,
    servings: 2,
    difficulty: "Easy",
    ingredients: [
      "2 salmon fillets",
      "2 tbsp olive oil",
      "1 lemon, sliced",
      "2 cloves garlic, minced",
      "Fresh dill",
      "Salt and pepper to taste"
    ],
    instructions: [
      "Preheat grill to medium-high heat.",
      "Brush salmon with olive oil and season with salt and pepper.",
      "Sprinkle minced garlic over the salmon.",
      "Place lemon slices on top of each fillet.",
      "Grill for 4-5 minutes per side until fish flakes easily.",
      "Garnish with fresh dill and serve with vegetables."
    ]
  },
  {
    id: "3",
    title: "Decadent Chocolate Cake",
    description: "Rich, moist chocolate layer cake with ganache",
    image: "https://images.unsplash.com/photo-1736840334919-aac2d5af73e4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaG9jb2xhdGUlMjBkZXNzZXJ0JTIwY2FrZXxlbnwxfHx8fDE3NzIwMTMyNDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Dessert",
    time: 90,
    servings: 8,
    difficulty: "Hard",
    ingredients: [
      "2 cups all-purpose flour",
      "2 cups sugar",
      "3/4 cup cocoa powder",
      "2 tsp baking soda",
      "1 tsp salt",
      "2 eggs",
      "1 cup buttermilk",
      "1 cup strong coffee",
      "1/2 cup vegetable oil",
      "1 tsp vanilla extract",
      "300g dark chocolate for ganache",
      "1 cup heavy cream"
    ],
    instructions: [
      "Preheat oven to 350°F (175°C). Grease two 9-inch round pans.",
      "Mix flour, sugar, cocoa, baking soda, and salt in a large bowl.",
      "Add eggs, buttermilk, coffee, oil, and vanilla. Beat until smooth.",
      "Pour batter evenly into prepared pans.",
      "Bake for 30-35 minutes until a toothpick comes out clean.",
      "Cool in pans for 10 minutes, then turn out onto wire racks.",
      "For ganache, heat cream until simmering, pour over chopped chocolate, stir until smooth.",
      "Let ganache cool slightly, then spread between layers and over cake."
    ]
  },
  {
    id: "4",
    title: "Avocado Toast Supreme",
    description: "Creamy avocado on sourdough with poached egg",
    image: "https://images.unsplash.com/photo-1604634077134-6f774f610f47?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmcmVzaCUyMGJyZWFrZmFzdCUyMGF2b2NhZG8lMjB0b2FzdHxlbnwxfHx8fDE3NzIwMzQ4NDF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Breakfast",
    time: 10,
    servings: 2,
    difficulty: "Easy",
    ingredients: [
      "2 slices sourdough bread",
      "1 ripe avocado",
      "2 eggs",
      "Cherry tomatoes, halved",
      "Red pepper flakes",
      "Lemon juice",
      "Salt and pepper to taste"
    ],
    instructions: [
      "Toast sourdough bread until golden brown.",
      "Mash avocado with lemon juice, salt, and pepper.",
      "Bring a pot of water to simmer for poached eggs.",
      "Crack eggs into water and poach for 3-4 minutes.",
      "Spread avocado mixture on toast.",
      "Top with poached egg, cherry tomatoes, and red pepper flakes."
    ]
  },
  {
    id: "5",
    title: "Chicken Tikka Masala",
    description: "Tender chicken in creamy tomato-based curry sauce",
    image: "https://images.unsplash.com/photo-1764304733301-3a9f335f0c67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGlja2VuJTIwY3VycnklMjBib3dsfGVufDF8fHx8MTc3MTk2MDY5MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Indian",
    time: 45,
    servings: 4,
    difficulty: "Medium",
    ingredients: [
      "600g chicken breast, cubed",
      "1 cup yogurt",
      "2 tbsp tikka masala spice blend",
      "1 onion, diced",
      "3 cloves garlic, minced",
      "1 tbsp ginger, grated",
      "400g crushed tomatoes",
      "1 cup heavy cream",
      "Fresh cilantro",
      "Basmati rice for serving"
    ],
    instructions: [
      "Marinate chicken in yogurt and half the spice blend for 30 minutes.",
      "Sauté onion, garlic, and ginger in oil until soft.",
      "Add remaining spices and cook until fragrant.",
      "Add tomatoes and simmer for 10 minutes.",
      "In a separate pan, cook marinated chicken until golden.",
      "Add chicken to sauce with heavy cream.",
      "Simmer for 10 minutes and garnish with cilantro.",
      "Serve over basmati rice."
    ]
  },
  {
    id: "6",
    title: "Vegetable Stir Fry",
    description: "Colorful mix of fresh vegetables in savory sauce",
    image: "https://images.unsplash.com/photo-1464500650248-1a4b45debb9f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2ZWdldGFibGUlMjBzdGlyJTIwZnJ5fGVufDF8fHx8MTc3MTk3MDA4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Asian",
    time: 20,
    servings: 4,
    difficulty: "Easy",
    ingredients: [
      "2 cups broccoli florets",
      "1 bell pepper, sliced",
      "1 cup snap peas",
      "2 carrots, julienned",
      "3 tbsp soy sauce",
      "2 tbsp oyster sauce",
      "1 tbsp sesame oil",
      "2 cloves garlic, minced",
      "1 tsp ginger, grated",
      "Sesame seeds for garnish"
    ],
    instructions: [
      "Heat sesame oil in a wok or large pan over high heat.",
      "Add garlic and ginger, stir fry for 30 seconds.",
      "Add harder vegetables (carrots, broccoli) first.",
      "Stir fry for 3-4 minutes.",
      "Add bell pepper and snap peas.",
      "Mix soy sauce and oyster sauce, pour over vegetables.",
      "Toss everything for 2-3 minutes until vegetables are tender-crisp.",
      "Garnish with sesame seeds and serve over rice or noodles."
    ]
  },
  {
    id: "7",
    title: "Classic Beef Burger",
    description: "Juicy homemade burger with all the fixings",
    image: "https://images.unsplash.com/photo-1651843465180-5965076f7368?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXJnZXIlMjBmcmllcyUyMG1lYWx8ZW58MXx8fHwxNzcyMDAzMDI2fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "American",
    time: 30,
    servings: 4,
    difficulty: "Easy",
    ingredients: [
      "500g ground beef (80/20)",
      "4 burger buns",
      "4 slices cheese",
      "Lettuce leaves",
      "Tomato slices",
      "Red onion slices",
      "Pickles",
      "Ketchup and mustard",
      "Salt and pepper"
    ],
    instructions: [
      "Divide beef into 4 equal portions and form into patties.",
      "Season both sides with salt and pepper.",
      "Heat grill or pan to medium-high heat.",
      "Cook patties for 4-5 minutes per side.",
      "Add cheese in the last minute of cooking.",
      "Toast buns lightly on the grill.",
      "Assemble burgers with lettuce, tomato, onion, pickles, and condiments.",
      "Serve with fries or salad."
    ]
  },
  {
    id: "8",
    title: "Green Smoothie Bowl",
    description: "Nutritious breakfast bowl packed with fruits and greens",
    image: "https://images.unsplash.com/photo-1642423453782-38590d54a131?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlbiUyMHNtb290aGllJTIwYm93bHxlbnwxfHx8fDE3NzIwMTQzMjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Breakfast",
    time: 10,
    servings: 2,
    difficulty: "Easy",
    ingredients: [
      "2 frozen bananas",
      "1 cup spinach",
      "1/2 cup mango chunks",
      "1/2 cup almond milk",
      "1 tbsp chia seeds",
      "Toppings: granola, berries, coconut flakes, honey"
    ],
    instructions: [
      "Add frozen bananas, spinach, mango, and almond milk to blender.",
      "Blend until smooth and creamy.",
      "Pour into bowls.",
      "Top with granola, fresh berries, coconut flakes, and chia seeds.",
      "Drizzle with honey if desired.",
      "Serve immediately."
    ]
  },
  {
    id: "9",
    title: "Street-Style Tacos",
    description: "Authentic Mexican tacos with seasoned meat and fresh toppings",
    image: "https://images.unsplash.com/photo-1552332386-f8dd00dc2f85?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtZXhpY2FuJTIwdGFjb3N8ZW58MXx8fHwxNzcyMDM0ODQzfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Mexican",
    time: 25,
    servings: 4,
    difficulty: "Easy",
    ingredients: [
      "500g beef or chicken, diced",
      "8 small corn tortillas",
      "1 onion, diced",
      "Fresh cilantro, chopped",
      "2 limes, cut into wedges",
      "2 tsp cumin",
      "1 tsp chili powder",
      "1 tsp paprika",
      "Salsa and hot sauce",
      "Crumbled queso fresco"
    ],
    instructions: [
      "Season meat with cumin, chili powder, paprika, salt, and pepper.",
      "Heat oil in a pan and cook meat until browned and cooked through.",
      "Warm tortillas in a dry pan or over flame.",
      "Fill each tortilla with cooked meat.",
      "Top with diced onion, cilantro, and queso fresco.",
      "Serve with lime wedges, salsa, and hot sauce on the side."
    ]
  },
  {
    id: "10",
    title: "Greek Salad",
    description: "Fresh Mediterranean salad with feta and olives",
    image: "https://images.unsplash.com/photo-1563046937-1f82e1a115cd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmVlayUyMHNhbGFkJTIwaGVhbHRoeXxlbnwxfHx8fDE3NzE5OTgxNjd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Mediterranean",
    time: 15,
    servings: 4,
    difficulty: "Easy",
    ingredients: [
      "4 tomatoes, cut into wedges",
      "1 cucumber, sliced",
      "1 red onion, thinly sliced",
      "1 green bell pepper, chopped",
      "1 cup Kalamata olives",
      "200g feta cheese, cubed",
      "1/4 cup olive oil",
      "2 tbsp red wine vinegar",
      "1 tsp dried oregano",
      "Salt and pepper to taste"
    ],
    instructions: [
      "Combine tomatoes, cucumber, onion, and bell pepper in a large bowl.",
      "Add olives and feta cheese.",
      "In a small bowl, whisk together olive oil, vinegar, oregano, salt, and pepper.",
      "Pour dressing over salad and toss gently.",
      "Let sit for 10 minutes for flavors to meld.",
      "Serve with pita bread."
    ]
  },
  {
    id: "11",
    title: "Margherita Pizza",
    description: "Classic Italian pizza with tomato, mozzarella, and basil",
    image: "https://images.unsplash.com/photo-1628840042765-356cda07504e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZXBwZXJvbmklMjBwaXp6YXxlbnwxfHx8fDE3NzE5ODIxNDJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Italian",
    time: 90,
    servings: 2,
    difficulty: "Medium",
    ingredients: [
      "Pizza dough (store-bought or homemade)",
      "1 cup tomato sauce",
      "250g fresh mozzarella, sliced",
      "Fresh basil leaves",
      "2 tbsp olive oil",
      "2 cloves garlic, minced",
      "Salt to taste"
    ],
    instructions: [
      "Preheat oven to 475°F (245°C) with pizza stone if available.",
      "Roll out pizza dough on a floured surface.",
      "Mix tomato sauce with garlic and a pinch of salt.",
      "Spread sauce evenly over dough, leaving a border.",
      "Arrange mozzarella slices on top.",
      "Drizzle with olive oil.",
      "Bake for 12-15 minutes until crust is golden and cheese is bubbly.",
      "Remove from oven and top with fresh basil leaves before serving."
    ]
  },
  {
    id: "12",
    title: "Grilled Ribeye Steak",
    description: "Perfectly seasoned and grilled ribeye with roasted vegetables",
    image: "https://images.unsplash.com/photo-1723180907020-16eaa8763ca7?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZWVmJTIwc3RlYWslMjB2ZWdldGFibGVzfGVufDF8fHx8MTc3MTk2MDQzN3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "American",
    time: 30,
    servings: 2,
    difficulty: "Medium",
    ingredients: [
      "2 ribeye steaks (about 300g each)",
      "2 tbsp olive oil",
      "4 cloves garlic, smashed",
      "Fresh rosemary sprigs",
      "Coarse sea salt",
      "Black pepper",
      "2 tbsp butter",
      "Assorted vegetables for roasting"
    ],
    instructions: [
      "Remove steaks from refrigerator 30 minutes before cooking.",
      "Preheat grill to high heat.",
      "Season steaks generously with salt and pepper.",
      "Brush with olive oil.",
      "Grill for 4-5 minutes per side for medium-rare.",
      "In the last minute, add butter, garlic, and rosemary to the steaks.",
      "Let steaks rest for 5 minutes before serving.",
      "Serve with roasted vegetables."
    ]
  }
];

export const categories = [
  "All",
  "Italian",
  "Seafood",
  "Dessert",
  "Breakfast",
  "Indian",
  "Asian",
  "American",
  "Mexican",
  "Mediterranean"
];
