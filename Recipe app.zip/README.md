
  # Recipe app

  This is a code bundle for Recipe app. The original project is available at https://www.figma.com/design/yAOHrpE4nqDwDNDseu0BsV/Recipe-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  